/** @type {import('next').NextConfig} */
const nextConfig = {
  images: { remotePatterns: [{ protocol: 'https', hostname: 'bidspirit-images.global.ssl.fastly.net' }] }
};
export default nextConfig;
