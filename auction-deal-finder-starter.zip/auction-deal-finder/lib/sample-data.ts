export type Deal = { lot:number; title:string; resale:number; maxBid:number; profit:number; confidence:"High"|"Medium"|"Low"; recommendation:"BUY"|"WATCH"|"PASS"; url:string };
export const sampleDeals: Deal[] = [
 {lot:104,title:"Canon T90 with Canon FD 15mm f/2.8 fisheye",resale:600,maxBid:261,profit:180,confidence:"High",recommendation:"BUY",url:"https://bid.rosanreevesauctions.co.uk/auction/234-235-lots-located/lot-104-canon-t90/"},
 {lot:180,title:"PS5 Slim Digital with two DualSense controllers",resale:325,maxBid:137,profit:98,confidence:"High",recommendation:"BUY",url:"https://bid.rosanreevesauctions.co.uk/auction/234-235-lots-located/lot-180-sony-playstation/"},
 {lot:216,title:"PS5 Disc Edition with two controllers",resale:295,maxBid:124,profit:89,confidence:"High",recommendation:"BUY",url:"https://bid.rosanreevesauctions.co.uk/auction/234-235-lots-located/lot-216-a-carton/"},
 {lot:165,title:"Five Tamiya 1:12 Formula 1 model kits",resale:450,maxBid:188,profit:135,confidence:"Medium",recommendation:"WATCH",url:"https://bid.rosanreevesauctions.co.uk/auction/234-235-lots-located/lot-165-a-collection-2/"},
 {lot:1,title:"Custom gaming PC with RTX 3070 Vision OC",resale:450,maxBid:188,profit:135,confidence:"Medium",recommendation:"WATCH",url:"https://bid.rosanreevesauctions.co.uk/auction/234-235-lots-located/lot-1-custom-gaming/"}
];
