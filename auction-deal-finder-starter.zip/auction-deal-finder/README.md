# Auction Deal Finder

Mobile-friendly Next.js dashboard starter for auction sourcing and eBay resale analysis.

## Deploy
1. Upload these files to the GitHub repository.
2. Import the repository into Vercel.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel.
4. Deploy.

The first deployment uses sample Rosan Reeves deal data. Next comes the Supabase and Apify data pipeline.
