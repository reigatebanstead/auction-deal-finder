import type { Deal } from "@/lib/sample-data";
export function DealCard({ deal }: { deal: Deal }) {
 return <article className="deal-card">
  <div className="deal-topline"><span>Lot {deal.lot}</span><span className={`badge ${deal.recommendation.toLowerCase()}`}>{deal.recommendation}</span></div>
  <h3>{deal.title}</h3>
  <dl>
   <div><dt>Expected resale</dt><dd>£{deal.resale}</dd></div>
   <div><dt>Max hammer</dt><dd>£{deal.maxBid}</dd></div>
   <div><dt>Expected profit</dt><dd>£{deal.profit}</dd></div>
   <div><dt>Confidence</dt><dd>{deal.confidence}</dd></div>
  </dl>
  <a href={deal.url} target="_blank" rel="noreferrer">Open auction lot</a>
 </article>;
}
