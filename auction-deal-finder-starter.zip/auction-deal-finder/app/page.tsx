import { DealCard } from "@/components/DealCard";
import { sampleDeals } from "@/lib/sample-data";
export default function HomePage() {
 return <main>
  <header className="hero"><div><p className="eyebrow">Auction intelligence</p><h1>Auction Deal Finder</h1><p className="intro">Compare auction lots with recent eBay sold prices, calculate a safe maximum bid, and focus on the strongest resale opportunities.</p></div><div className="status">Prototype online</div></header>
  <section className="stats"><article><span>Live auctions</span><strong>1</strong></article><article><span>Lots analysed</span><strong>15</strong></article><article><span>Top opportunities</span><strong>5</strong></article><article><span>Potential profit</span><strong>£636</strong></article></section>
  <section className="toolbar"><div><p className="eyebrow">Current auction</p><h2>Rosan Reeves — Hailsham</h2></div><input aria-label="Search lots" placeholder="Search lots, brands or models…" /></section>
  <section className="grid">{sampleDeals.map((deal)=><DealCard key={deal.lot} deal={deal}/>)}</section>
 </main>;
}
